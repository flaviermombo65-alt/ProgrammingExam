import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SalesLogReader {

    private final String fileName;

    public SalesLogReader(String fileName) {
        this.fileName = fileName;
    }

    // Returns every saved sale, one line per sale. Empty list if no file yet.
    public List<String> ReadAll() throws IOException {
        List<String> records = new ArrayList<>();
        java.io.File file = new java.io.File(fileName);
        if (!file.exists()) {
            return records;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    records.add(line);
                }
            }
        }
        return records;
    }
}

