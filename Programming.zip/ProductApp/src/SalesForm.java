import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;

public class SalesForm extends JFrame {

    private static final String FILE_NAME = "data.txt";

    private final JTextField txtCustomer = new JTextField(20);
    private final JComboBox<String> cmbProduct = new JComboBox<>(new String[]{
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
    });
    private final JTextField txtPrice = new JTextField(20);
    private final JTextField txtVat = new JTextField(20);
    private final JTextField txtCommission = new JTextField(20);
    private final JTextField txtTotal = new JTextField(20);

    public SalesForm() {
        super("Mattress Sales Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setJMenuBar(buildMenuBar());
        add(buildFormPanel());

        pack();
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private JMenuBar buildMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic('F');
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        toolsMenu.setMnemonic('T');
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(e -> processSale());   // same logic as the button
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearForm());
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        return menuBar;
    }

    private JPanel buildFormPanel() {
        JPanel panel = new JPanel(new GridLayout(0, 2, 10, 10));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        // Calculated fields are display-only
        txtVat.setEditable(false);
        txtCommission.setEditable(false);
        txtTotal.setEditable(false);

        panel.add(new JLabel("Customer name:"));
        panel.add(txtCustomer);
        panel.add(new JLabel("Product name:"));
        panel.add(cmbProduct);
        panel.add(new JLabel("Product price (R):"));
        panel.add(txtPrice);
        panel.add(new JLabel("VAT amount (15%):"));
        panel.add(txtVat);
        panel.add(new JLabel("Commission amount (5%):"));
        panel.add(txtCommission);
        panel.add(new JLabel("Total sale amount:"));
        panel.add(txtTotal);

        JButton btnProcess = new JButton("Process");
        btnProcess.addActionListener(e -> processSale());
        panel.add(new JLabel());   // empty cell so the button sits under the text boxes
        panel.add(btnProcess);

        return panel;
    }

    // Shared by the Process button and Tools > Process
    private void processSale() {
        String customer = txtCustomer.getText().trim();
        String product = (String) cmbProduct.getSelectedItem();

        if (customer.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the customer's name.",
                    "Missing information", JOptionPane.WARNING_MESSAGE);
            txtCustomer.requestFocus();
            return;
        }

        double price;
        try {
            price = Double.parseDouble(txtPrice.getText().trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number for the price.",
                    "Invalid price", JOptionPane.WARNING_MESSAGE);
            txtPrice.requestFocus();
            return;
        }
        if (price <= 0) {
            JOptionPane.showMessageDialog(this, "The price must be greater than zero.",
                    "Invalid price", JOptionPane.WARNING_MESSAGE);
            txtPrice.requestFocus();
            return;
        }

        IProductCalculations calc = new ProductCalculations(price);
        double vat = calc.GetVat();
        double commission = calc.GetCommission();
        double total = calc.GetTotal();

        txtVat.setText(String.format(Locale.US, "R %.2f", vat));
        txtCommission.setText(String.format(Locale.US, "R %.2f", commission));
        txtTotal.setText(String.format(Locale.US, "R %.2f", total));

        saveToFile(customer, product, vat, commission, total);
    }

    private void saveToFile(String customer, String product,
                            double vat, double commission, double total) {
        // true = append, so earlier sales are kept
        try (PrintWriter out = new PrintWriter(new FileWriter(FILE_NAME, true))) {
            out.println(String.format(Locale.US,
                    "Customer: %s | Product: %s | VAT: R%.2f | Commission: R%.2f | Total: R%.2f",
                    customer, product, vat, commission, total));
            JOptionPane.showMessageDialog(this, "Sale processed and saved to " + FILE_NAME + ".",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not save to " + FILE_NAME + ": " + ex.getMessage(),
                    "File error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm() {
        txtCustomer.setText("");
        txtPrice.setText("");
        txtVat.setText("");
        txtCommission.setText("");
        txtTotal.setText("");
        cmbProduct.setSelectedIndex(0);
        txtCustomer.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SalesForm().setVisible(true));
    }
}