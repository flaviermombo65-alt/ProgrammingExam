public class PrintProduct {

    private final Products products;

    public PrintProduct(Products products) {
        this.products = products;
    }

    public void PrintSalesTable(String[] months) {
        String[] names = products.GetProductNames();
        int[][] sales = products.GetSales();

        System.out.printf("%-24s", "Product");
        for (String m : months) System.out.printf("%8s", m);
        System.out.printf("%8s%n", "Total");
        System.out.println("-".repeat(24 + 8 * (months.length + 1)));

        for (int p = 0; p < names.length; p++) {
            System.out.printf("%-24s", names[p]);
            for (int m = 0; m < sales[p].length; m++) {
                System.out.printf("%8d", sales[p][m]);
            }
            System.out.printf("%8d%n", products.GetProductTotal(p));
        }
        System.out.println();
    }

    public void PrintTotalProductSales() {
        System.out.println("Total number of products sold: " + products.GetTotalProduct());
    }

    public void PrintAverageProductSales() {
        System.out.printf("Average products sold per product: %.2f%n",
                products.GetAverageProductsold());
    }

    public void PrintMostPopularBySale() {
        System.out.println("Most popular product (highest total sales): "
                + products.GetMostPopularProduct());
    }
}