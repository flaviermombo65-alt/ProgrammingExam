public class Products implements IProduct {

    private final String[] productNames;  
    private final int[][] sales;           

    public Products(String[] productNames, int[][] sales) {
        this.productNames = productNames;
        this.sales = sales;
    }

    
    public int GetProductTotal(int productIndex) {
        int total = 0;
        for (int month = 0; month < sales[productIndex].length; month++) {
            total += sales[productIndex][month];
        }
        return total;
    }

   
    public int GetTotalProduct() {
        int total = 0;
        for (int p = 0; p < sales.length; p++) {
            total += GetProductTotal(p);
        }
        return total;
    }

  
    public double GetAverageProductsold() {
        return (double) GetTotalProduct() / productNames.length;
    }

    
    public String GetMostPopularProduct() {
        int bestIndex = 0;
        for (int p = 1; p < sales.length; p++) {
            if (GetProductTotal(p) > GetProductTotal(bestIndex)) {
                bestIndex = p;
            }
        }
        return productNames[bestIndex];
    }

    public String[] GetProductNames() { return productNames; }
    public int[][] GetSales()         { return sales; }
}