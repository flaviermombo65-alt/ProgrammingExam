public interface IProduct {
    int GetTotalProduct();
    double GetAverageProductsold();
    String GetMostPopularProduct();
}