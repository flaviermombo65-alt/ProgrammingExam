public class Main {
    public static void main(String[] args) {
        String[] months = {"Aug", "Sep", "Oct"};

        String[] productNames = {
            "Comfort Queen",
            "Memory Foam Deluxe",
            "Spring King"
        };


        int[][] sales = {
            {42, 38, 51},
            {35, 47, 44},
            {29, 33, 31}
        };

        Products products = new Products(productNames, sales);
        PrintProduct printer = new PrintProduct(products);

        System.out.println("===== MATTRESS SALES REPORT (Top 3 Products, 3 Months) =====\n");
        printer.PrintSalesTable(months);
        printer.PrintTotalProductSales();
        printer.PrintAverageProductSales();
        printer.PrintMostPopularBySale();
    }
}
